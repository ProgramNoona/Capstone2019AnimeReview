.. _accountmanagement:

Account Management
==================

.. autoclass:: flaskbb.core.auth.password.ResetPasswordService
    :members:

.. autoclass:: flaskbb.core.auth.activation.AccountActivator
    :members:
